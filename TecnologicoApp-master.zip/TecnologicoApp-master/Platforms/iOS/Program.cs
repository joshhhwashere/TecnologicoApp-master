﻿using ObjCRuntime;
using UIKit;

namespace TecnologicoApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            
            UIApplication.Main(args, null, typeof(AppDelegate));
        }
    }
}
